/*6) Em uma fábrica de reciclagem de materiais, cada 10kg de plástico rendem R$2,00 cada 30kg de papel rendem R$3,00 e cada 50kg de metal rendem R$5,00. 
Perguntar ao usuário a quantidade (kg) de cada material que deseja entregar na fábrica e mostrar o total que receberá em reais.*/

var plastico, papel, metal

plastico = prompt('Quantos kilos de plastico você têm')
papel = prompt('Quantos kilos de papel você têm')
metal = prompt('Quantos kilos de papel você')

alert('Baseado nos pesos, com suas vendas você ganhara ' + plastico * 0,2 + ' reais de plástico, ' + papel * 0,1 + ' reais de papel, e ' + metal * 0,1 + 'reais de metal.')