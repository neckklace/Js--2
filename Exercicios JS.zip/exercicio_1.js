/*1) Faça um programa no qual o usuário digite dois números e mostre na tela a multiplicação desses números.*/

var numero1, numero2
var resultado

numero1 = prompt('Digite o primeiro número')
numero2 = prompt('Digite o segundo número')
resultado = numero1 * numero2

alert(numero1 + ' * ' + numero2 + ' = ' + resultado)