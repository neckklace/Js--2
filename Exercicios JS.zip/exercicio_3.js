/*3) Programar a conversão de uma temperatura digitada pelo usuário em graus Celsius para Fahrenheit. Mostrar o resultado na tela.*/

var celcius, fahrenheit

calcius = prompt('Indique a temperatura em Celcius')

fahrenheit = (celcius * (9/5)) + 32

alert('O resultado é: ' + fahrenheit + 'fahrenheit')